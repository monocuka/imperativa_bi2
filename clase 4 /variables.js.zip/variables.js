 
//  //llegar al trabajo//
 
//  let organizacion = true;
 
//  let llueve = false;
     
//  let rutaBus = 15;

//  let parada = 'avenida 30 de agosto';

//  let numerOficina = 302;

//  let nombreEmpresa = 'aumentada';

//  console.log(organizacion,llueve,rutaBus,parada,numerOficina,nombreEmpresa);


let cajonCamisetas = 'pantalones';

cajonCamisetas = 'camisetas';
console.log(cajonCamisetas)







    